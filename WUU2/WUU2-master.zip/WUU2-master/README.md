# WUU2
Windows Update Utility (WUU) Fixed
This was an update of the PoshPIAG project updated by Tyler Siegrist and Fixed by Phaere in the comment. I just put it all together here for others to take over.

To make this work make sure you download PSExec and put it in the WUU2 folder.

https://docs.microsoft.com/en-us/sysinternals/downloads/psexec

Original Project.

https://gallery.technet.microsoft.com/scriptcenter/Windows-Update-Utility-WUU-1d72e520?fbclid=IwAR0NthM8UCW-ecNrASTC4VDiBROqfpHD_oUpTRU6uEL8PjO8TgEuji7EhKk
